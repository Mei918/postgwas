"""Core data models."""
