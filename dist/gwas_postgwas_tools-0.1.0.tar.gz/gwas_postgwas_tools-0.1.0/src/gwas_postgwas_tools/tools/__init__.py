"""External tool adapters."""
